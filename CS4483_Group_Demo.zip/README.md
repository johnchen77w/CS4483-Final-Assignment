# CS4483-Final-Assignment

# Team-Members
- Wenxi Chen		wchen466@uwo.ca     250949386
- Ruiqi Chen		rchen295@uwo.ca     250964150
- Dingze Yu			dyu97@uwo.ca     		250838916
- Wenhan Sun		wsun228@uwo.ca     	251020850
- Rui Wang			rwang464@uwo.ca     250974159

# Gameplay-Controls
There are five levels in this game. Once you successfully reach the end of each level, you will automatically enter the next level. If you die, you will be
reset back to the starting point of the current level. 
- a: left
- s: right
- space: jump
